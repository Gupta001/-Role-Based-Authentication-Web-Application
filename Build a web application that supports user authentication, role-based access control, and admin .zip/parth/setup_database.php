<?php
echo "<h2>Database Setup for User Management System</h2>";

// Database connection parameters
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'parth';

try {
    // First, connect without specifying database to create it
    echo "<p>Step 1: Connecting to MySQL server...</p>";
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✓ Connected to MySQL server successfully!</p>";

    // Create database if it doesn't exist
    echo "<p>Step 2: Creating database '$db_name'...</p>";
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name`");
    echo "<p style='color: green;'>✓ Database '$db_name' created/verified!</p>";

    // Connect to the specific database
    echo "<p>Step 3: Connecting to database '$db_name'...</p>";
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✓ Connected to database '$db_name' successfully!</p>";

    // Create users table
    echo "<p>Step 4: Creating users table...</p>";
    $createTable = "
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin', 'student') DEFAULT 'student',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ";
    $pdo->exec($createTable);
    echo "<p style='color: green;'>✓ Users table created successfully!</p>";

    // Insert default admin user
    echo "<p>Step 5: Creating default admin user...</p>";
    $adminPassword = password_hash('Admin123!', PASSWORD_DEFAULT);
    $insertAdmin = "INSERT IGNORE INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($insertAdmin);
    $stmt->execute(['admin', 'admin@example.com', $adminPassword, 'admin']);
    echo "<p style='color: green;'>✓ Default admin user created!</p>";

    // Insert default student user
    echo "<p>Step 6: Creating default student user...</p>";
    $studentPassword = password_hash('Student123!', PASSWORD_DEFAULT);
    $insertStudent = "INSERT IGNORE INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($insertStudent);
    $stmt->execute(['student1', 'student1@example.com', $studentPassword, 'student']);
    echo "<p style='color: green;'>✓ Default student user created!</p>";

    // Verify setup
    echo "<p>Step 7: Verifying setup...</p>";
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
    $count = $stmt->fetch()['count'];
    echo "<p style='color: green;'>✓ Setup complete! Found $count users in database.</p>";

    // Show users
    echo "<h3>Users in database:</h3>";
    $stmt = $pdo->query("SELECT id, username, email, role, created_at FROM users");
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Created</th></tr>";
    while ($row = $stmt->fetch()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['role'] . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";

    echo "<hr>";
    echo "<h3 style='color: green;'>🎉 Database Setup Complete!</h3>";
    echo "<p><strong>Default Credentials:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Admin:</strong> Username: <code>admin</code>, Password: <code>Admin123!</code></li>";
    echo "<li><strong>Student:</strong> Username: <code>student1</code>, Password: <code>Student123!</code></li>";
    echo "</ul>";
    echo "<p><a href='index.html' style='background: #667eea; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Application</a></p>";

} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p><strong>Common solutions:</strong></p>";
    echo "<ul>";
    echo "<li>Make sure XAMPP is running (Apache and MySQL services)</li>";
    echo "<li>Check if MySQL is running on port 3306</li>";
    echo "<li>Verify MySQL username/password (default is root with no password)</li>";
    echo "</ul>";
}
?>
