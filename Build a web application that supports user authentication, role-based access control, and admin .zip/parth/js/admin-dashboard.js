let currentUser = null;
let users = [];
let isEditMode = false;

// Check authentication on page load
window.addEventListener('load', async function() {
    await checkAuth();
    await loadUsers();
});

async function checkAuth() {
    try {
        const response = await fetch('api/auth.php');
        const data = await response.json();
        
        if (!data.success || data.user.role !== 'admin') {
            window.location.href = 'login.html';
            return;
        }
        
        currentUser = data.user;
        document.getElementById('username-display').textContent = currentUser.username;
    } catch (error) {
        window.location.href = 'login.html';
    }
}

async function loadUsers() {
    try {
        const response = await fetch('api/users.php');
        const data = await response.json();
        
        if (data.success) {
            users = data.users;
            renderUsersTable();
        } else {
            showAlert('Failed to load users: ' + data.message, 'error');
        }
    } catch (error) {
        showAlert('Network error while loading users', 'error');
    }
}

function renderUsersTable() {
    const tbody = document.getElementById('users-table-body');
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No users found</td></tr>';
        return;
    }
    
    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>${user.username}</td>
            <td>${user.email}</td>
            <td><span class="user-role ${user.role}">${user.role}</span></td>
            <td>${new Date(user.created_at).toLocaleDateString()}</td>
            <td>
                <button class="btn btn-secondary btn-small" onclick="editUser(${user.id})">Edit</button>
                <button class="btn btn-danger btn-small" onclick="deleteUser(${user.id})">Delete</button>
            </td>
        </tr>
    `).join('');
}

function openCreateUserModal() {
    isEditMode = false;
    document.getElementById('modal-title').textContent = 'Add New User';
    document.getElementById('userForm').reset();
    document.getElementById('user-id').value = '';
    document.getElementById('password-group').style.display = 'block';
    document.getElementById('modal-password').required = true;
    document.getElementById('userModal').style.display = 'block';
}

function editUser(userId) {
    const user = users.find(u => u.id == userId);
    if (!user) return;
    
    isEditMode = true;
    document.getElementById('modal-title').textContent = 'Edit User';
    document.getElementById('user-id').value = user.id;
    document.getElementById('modal-username').value = user.username;
    document.getElementById('modal-email').value = user.email;
    document.getElementById('modal-role').value = user.role;
    document.getElementById('password-group').style.display = 'none';
    document.getElementById('modal-password').required = false;
    document.getElementById('userModal').style.display = 'block';
}

function closeUserModal() {
    document.getElementById('userModal').style.display = 'none';
}

async function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user?')) return;
    
    try {
        const response = await fetch(`api/users.php?id=${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('User deleted successfully', 'success');
            await loadUsers();
        } else {
            showAlert('Failed to delete user: ' + data.message, 'error');
        }
    } catch (error) {
        showAlert('Network error while deleting user', 'error');
    }
}

// Handle user form submission
document.getElementById('userForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const userData = {
        username: formData.get('username'),
        email: formData.get('email'),
        role: formData.get('role')
    };
    
    if (!isEditMode) {
        userData.password = formData.get('password');
    }
    
    // Show loading
    document.getElementById('save-text').classList.add('hidden');
    document.getElementById('save-loading').classList.remove('hidden');
    
    try {
        let url = 'api/users.php';
        let method = 'POST';
        
        if (isEditMode) {
            url += `?id=${formData.get('user-id')}`;
            method = 'PUT';
        }
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(isEditMode ? 'User updated successfully' : 'User created successfully', 'success');
            closeUserModal();
            await loadUsers();
        } else {
            showAlert(data.message, 'error');
        }
    } catch (error) {
        showAlert('Network error. Please try again.', 'error');
    } finally {
        // Hide loading
        document.getElementById('save-text').classList.remove('hidden');
        document.getElementById('save-loading').classList.add('hidden');
    }
});

async function logout() {
    try {
        await fetch('api/auth.php?action=logout', { method: 'POST' });
        window.location.href = 'login.html';
    } catch (error) {
        window.location.href = 'login.html';
    }
}

function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    alertContainer.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    
    // Auto-hide success messages
    if (type === 'success') {
        setTimeout(() => {
            alertContainer.innerHTML = '';
        }, 3000);
    }
}
