<?php
require_once '../config/database.php';
require_once '../models/User.php';
require_once '../middleware/auth.php';

// Set CORS headers
Auth::setCORSHeaders();

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

$method = $_SERVER['REQUEST_METHOD'];
$request = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'POST':
        $action = $_GET['action'] ?? '';
        
        if($action === 'register') {
            // Register new user
            if(!isset($request['username']) || !isset($request['email']) || !isset($request['password'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'message' => 'Username, email and password are required'
                ]);
                break;
            }

            $user->username = $request['username'];
            $user->email = $request['email'];
            $user->password = $request['password'];
            $user->role = $request['role'] ?? 'student';

            // Validate password
            $passwordValidation = $user->validatePassword($request['password']);
            if($passwordValidation !== true) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'message' => $passwordValidation
                ]);
                break;
            }

            // Check if user already exists
            if($user->userExists()) {
                http_response_code(409);
                echo json_encode([
                    'success' => false,
                    'message' => 'User with this username or email already exists'
                ]);
                break;
            }

            // Create user
            if($user->create()) {
                http_response_code(201);
                echo json_encode([
                    'success' => true,
                    'message' => 'User registered successfully'
                ]);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Unable to register user'
                ]);
            }

        } elseif($action === 'login') {
            // Login user
            if(!isset($request['username']) || !isset($request['password'])) {
                http_response_code(400);
                echo json_encode([
                    'success' => false,
                    'message' => 'Username and password are required'
                ]);
                break;
            }

            $user->username = $request['username'];
            $user->password = $request['password'];

            if($user->login()) {
                Auth::login($user->id, $user->username, $user->email, $user->role);
                
                http_response_code(200);
                echo json_encode([
                    'success' => true,
                    'message' => 'Login successful',
                    'user' => [
                        'id' => $user->id,
                        'username' => $user->username,
                        'email' => $user->email,
                        'role' => $user->role
                    ]
                ]);
            } else {
                http_response_code(401);
                echo json_encode([
                    'success' => false,
                    'message' => 'Invalid username or password'
                ]);
            }

        } elseif($action === 'logout') {
            // Logout user
            Auth::logout();
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Logout successful'
            ]);
        }
        break;

    case 'GET':
        // Get current user info
        if(Auth::isLoggedIn()) {
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'user' => Auth::getCurrentUser()
            ]);
        } else {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'message' => 'Not authenticated'
            ]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => 'Method not allowed'
        ]);
        break;
}
?>
