<?php
require_once '../config/database.php';
require_once '../models/User.php';
require_once '../middleware/auth.php';

// Set CORS headers
Auth::setCORSHeaders();

// Require admin access for all user management operations
Auth::requireAdmin();

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

$method = $_SERVER['REQUEST_METHOD'];
$request = json_decode(file_get_contents('php://input'), true);

switch($method) {
    case 'GET':
        if(isset($_GET['id'])) {
            // Get single user
            $user->id = $_GET['id'];
            if($user->readOne()) {
                http_response_code(200);
                echo json_encode([
                    'success' => true,
                    'user' => [
                        'id' => $user->id,
                        'username' => $user->username,
                        'email' => $user->email,
                        'role' => $user->role,
                        'created_at' => $user->created_at
                    ]
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'message' => 'User not found'
                ]);
            }
        } else {
            // Get all users
            $stmt = $user->readAll();
            $users = [];
            
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $users[] = [
                    'id' => $row['id'],
                    'username' => $row['username'],
                    'email' => $row['email'],
                    'role' => $row['role'],
                    'created_at' => $row['created_at']
                ];
            }
            
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'users' => $users
            ]);
        }
        break;

    case 'POST':
        // Create new user
        if(!isset($request['username']) || !isset($request['email']) || !isset($request['password'])) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Username, email and password are required'
            ]);
            break;
        }

        $user->username = $request['username'];
        $user->email = $request['email'];
        $user->password = $request['password'];
        $user->role = $request['role'] ?? 'student';

        // Validate password
        $passwordValidation = $user->validatePassword($request['password']);
        if($passwordValidation !== true) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => $passwordValidation
            ]);
            break;
        }

        // Check if user already exists
        if($user->userExists()) {
            http_response_code(409);
            echo json_encode([
                'success' => false,
                'message' => 'User with this username or email already exists'
            ]);
            break;
        }

        // Create user
        if($user->create()) {
            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'User created successfully'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Unable to create user'
            ]);
        }
        break;

    case 'PUT':
        // Update user
        if(!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'User ID is required'
            ]);
            break;
        }

        $user->id = $_GET['id'];
        $user->username = $request['username'] ?? '';
        $user->email = $request['email'] ?? '';
        $user->role = $request['role'] ?? '';

        if($user->update()) {
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'User updated successfully'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Unable to update user'
            ]);
        }
        break;

    case 'DELETE':
        // Delete user
        if(!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'User ID is required'
            ]);
            break;
        }

        $user->id = $_GET['id'];
        
        if($user->delete()) {
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'User deleted successfully'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Unable to delete user'
            ]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => 'Method not allowed'
        ]);
        break;
}
?>
