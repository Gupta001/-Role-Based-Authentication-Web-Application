-- Simple Database Setup for User Management System
-- Run this in phpMyAdmin or MySQL command line

-- Create database
CREATE DATABASE IF NOT EXISTS user_management;
USE user_management;

-- Create users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'student') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Add indexes for better performance
ALTER TABLE users ADD INDEX idx_username (username);
ALTER TABLE users ADD INDEX idx_email (email);
ALTER TABLE users ADD INDEX idx_role (role);

-- Insert default admin user (password: Admin123!)
INSERT INTO users (username, email, password, role) VALUES 
('admin', 'admin@example.com', '$2y$10$8K1p/a0dhrxiH8Tf/aZF4OXvLkrFBNy4i1WfLZjcqxV2M5FxVfHSC', 'admin');

-- Insert default student user (password: Student123!)
INSERT INTO users (username, email, password, role) VALUES 
('student1', 'student1@example.com', '$2y$10$8K1p/a0dhrxiH8Tf/aZF4OXvLkrFBNy4i1WfLZjcqxV2M5FxVfHSC', 'student');

-- Verify the setup
SELECT * FROM users;
SHOW TABLES;
