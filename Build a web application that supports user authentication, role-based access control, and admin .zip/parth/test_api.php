<?php
echo "<h2>API Connection Test</h2>";

// Test 1: Check if files exist
echo "<h3>Step 1: File Check</h3>";
$files = [
    'config/database.php',
    'models/User.php', 
    'middleware/auth.php',
    'api/auth.php'
];

foreach($files as $file) {
    if(file_exists($file)) {
        echo "<p style='color: green;'>✓ $file exists</p>";
    } else {
        echo "<p style='color: red;'>✗ $file missing</p>";
    }
}

// Test 2: Database connection
echo "<h3>Step 2: Database Connection Test</h3>";
try {
    require_once 'config/database.php';
    $database = new Database();
    $db = $database->getConnection();
    
    if($db) {
        echo "<p style='color: green;'>✓ Database connection successful</p>";
        
        // Test if users table exists
        $stmt = $db->query("SHOW TABLES LIKE 'users'");
        if($stmt->rowCount() > 0) {
            echo "<p style='color: green;'>✓ Users table exists</p>";
            
            // Count users
            $stmt = $db->query("SELECT COUNT(*) as count FROM users");
            $count = $stmt->fetch()['count'];
            echo "<p style='color: green;'>✓ Found $count users in database</p>";
            
            // Show users
            $stmt = $db->query("SELECT username, role FROM users");
            echo "<p><strong>Users:</strong></p><ul>";
            while($row = $stmt->fetch()) {
                echo "<li>{$row['username']} ({$row['role']})</li>";
            }
            echo "</ul>";
            
        } else {
            echo "<p style='color: red;'>✗ Users table does not exist</p>";
            echo "<p><a href='setup_database.php'>Click here to set up database</a></p>";
        }
    } else {
        echo "<p style='color: red;'>✗ Database connection failed</p>";
    }
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Database error: " . $e->getMessage() . "</p>";
}

// Test 3: API endpoint test
echo "<h3>Step 3: API Endpoint Test</h3>";
echo "<p>Testing API endpoint: <code>api/auth.php</code></p>";

// Simulate a login request
$testData = json_encode(['username' => 'admin', 'password' => 'Admin123!']);
$url = 'http://localhost/parth/api/auth.php?action=login';

echo "<p>Test URL: $url</p>";
echo "<p>If the API is working, you should be able to access it directly.</p>";
echo "<p><a href='api/auth.php' target='_blank'>Test API endpoint (should show 'Method not allowed' message)</a></p>";

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>If database connection failed: Make sure XAMPP MySQL is running</li>";
echo "<li>If users table doesn't exist: <a href='setup_database.php'>Run database setup</a></li>";
echo "<li>If everything looks good: <a href='login.html'>Try login page</a></li>";
echo "</ol>";
?>
