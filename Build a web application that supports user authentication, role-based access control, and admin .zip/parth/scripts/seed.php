<?php
require_once '../config/database.php';
require_once '../models/User.php';

echo "Starting database seeding...\n";

$database = new Database();
$db = $database->getConnection();

// Create users table if not exists (using 'parth' database)
$createTableQuery = "
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'student') DEFAULT 'student',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
";

try {
    $db->exec($createTableQuery);
    echo "✓ Users table created/verified in 'parth' database\n";
} catch(PDOException $e) {
    echo "✗ Error creating users table: " . $e->getMessage() . "\n";
    exit(1);
}

// Create default admin user
$user = new User($db);
$user->username = 'admin';
$user->email = 'admin@example.com';
$user->password = 'Admin123!';
$user->role = 'admin';

// Check if admin already exists
if(!$user->userExists()) {
    if($user->create()) {
        echo "✓ Default admin user created successfully\n";
        echo "  Username: admin\n";
        echo "  Email: admin@example.com\n";
        echo "  Password: Admin123!\n";
        echo "  Role: admin\n";
    } else {
        echo "✗ Failed to create default admin user\n";
    }
} else {
    echo "✓ Admin user already exists\n";
}

// Create a sample student user
$user = new User($db);
$user->username = 'student1';
$user->email = 'student1@example.com';
$user->password = 'Student123!';
$user->role = 'student';

if(!$user->userExists()) {
    if($user->create()) {
        echo "✓ Sample student user created successfully\n";
        echo "  Username: student1\n";
        echo "  Email: student1@example.com\n";
        echo "  Password: Student123!\n";
        echo "  Role: student\n";
    } else {
        echo "✗ Failed to create sample student user\n";
    }
} else {
    echo "✓ Sample student user already exists\n";
}

echo "\nDatabase seeding completed for 'parth' database!\n";
echo "\nDefault Credentials:\n";
echo "Admin - Username: admin, Password: Admin123!\n";
echo "Student - Username: student1, Password: Student123!\n";
?>
